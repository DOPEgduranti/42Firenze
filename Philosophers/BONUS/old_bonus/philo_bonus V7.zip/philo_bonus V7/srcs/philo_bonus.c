/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   philo_bonus.c                                      :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: gduranti <gduranti@student.42.fr>          +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2024/02/01 09:34:44 by gduranti          #+#    #+#             */
/*   Updated: 2024/02/06 10:08:09 by gduranti         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "philo_bonus.h"

int	main(int argc, char **argv)
{
	t_data	*data;

	ft_unlink();
	data = ft_datagen(argc, argv);
	ft_philo_gen(data);
	ft_wait(data);
	ft_freedata(data);
	ft_unlink();
	return (0);
}
